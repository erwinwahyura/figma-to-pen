// Export for pen.dev: serializes the current selection into Figma REST-shaped JSON
// that the Figma-to-.pen converter reads (document + components + variables).
figma.showUI(__html__, { width: 420, height: 360 });

const M = figma.mixed;
const num = v => (v === M || v == null ? undefined : v);

function handlesFromTransform(t) {
  // gradientTransform maps node space -> gradient space; invert it to find the handles
  const [[a, c, e], [b, d, f]] = t;
  const det = a * d - b * c || 1;
  const inv = ([x, y]) => {
    const X = x - e, Y = y - f;
    return { x: (d * X - c * Y) / det, y: (-b * X + a * Y) / det };
  };
  return [inv([0, 0.5]), inv([1, 0.5]), inv([0, 1])];
}

function paint(p) {
  const o = { type: p.type, visible: p.visible, opacity: p.opacity, blendMode: p.blendMode };
  if (p.type === "SOLID") { o.color = { ...p.color, a: 1 }; if (p.boundVariables && p.boundVariables.color) o.boundVariables = { color: p.boundVariables.color }; }
  else if (p.type.startsWith("GRADIENT_")) { o.gradientStops = p.gradientStops; o.gradientHandlePositions = handlesFromTransform(p.gradientTransform); }
  else if (p.type === "IMAGE") { o.imageRef = p.imageHash; o.scaleMode = p.scaleMode; }
  return o;
}
const paints = arr => (arr === M || !arr ? [] : arr.map(paint));

const componentsSeen = new Map();

async function ser(n) {
  const o = { id: n.id, type: n.type, name: n.name, visible: n.visible };
  if ("absoluteBoundingBox" in n && n.absoluteBoundingBox) o.absoluteBoundingBox = n.absoluteBoundingBox;
  if ("opacity" in n) o.opacity = n.opacity;
  if ("rotation" in n && n.rotation) o.rotation = n.rotation;
  if ("fills" in n) o.fills = paints(n.fills);
  if ("strokes" in n) {
    o.strokes = paints(n.strokes);
    o.strokeWeight = num(n.strokeWeight);
    if (n.strokeWeight === M && "strokeTopWeight" in n) o.individualStrokeWeights = { top: n.strokeTopWeight, right: n.strokeRightWeight, bottom: n.strokeBottomWeight, left: n.strokeLeftWeight };
    o.strokeAlign = n.strokeAlign; o.strokeCap = num(n.strokeCap); o.strokeJoin = num(n.strokeJoin);
    if (n.dashPattern && n.dashPattern.length) o.strokeDashes = n.dashPattern;
  }
  if ("effects" in n) o.effects = n.effects.map(e => ({ ...e }));
  if ("cornerRadius" in n) {
    if (n.cornerRadius === M) o.rectangleCornerRadii = [n.topLeftRadius, n.topRightRadius, n.bottomRightRadius, n.bottomLeftRadius];
    else o.cornerRadius = n.cornerRadius;
  }
  if ("layoutMode" in n) {
    Object.assign(o, { layoutMode: n.layoutMode, itemSpacing: n.itemSpacing, paddingTop: n.paddingTop, paddingRight: n.paddingRight,
      paddingBottom: n.paddingBottom, paddingLeft: n.paddingLeft, primaryAxisAlignItems: n.primaryAxisAlignItems,
      counterAxisAlignItems: n.counterAxisAlignItems, layoutWrap: n.layoutWrap, clipsContent: n.clipsContent,
      strokesIncludedInLayout: n.strokesIncludedInLayout });
  }
  if ("layoutSizingHorizontal" in n) { o.layoutSizingHorizontal = n.layoutSizingHorizontal; o.layoutSizingVertical = n.layoutSizingVertical; }
  if ("layoutPositioning" in n) o.layoutPositioning = n.layoutPositioning;
  if ("boundVariables" in n && n.boundVariables) o.boundVariables = n.boundVariables;
  if ("explicitVariableModes" in n && n.explicitVariableModes && Object.keys(n.explicitVariableModes).length) o.explicitVariableModes = n.explicitVariableModes;
  if ("arcData" in n) o.arcData = n.arcData;
  if ("pointCount" in n) o.pointCount = n.pointCount;
  // Plugin API paths use `data`; the converter reads the REST shape (`path`)
  const geom = list => (list === M || !list ? [] : list.map(g => ({ path: g.data, windingRule: g.windingRule })));
  if ("fillGeometry" in n) { o.fillGeometry = geom(n.fillGeometry); o.strokeGeometry = geom(n.strokeGeometry); }

  if (n.type === "TEXT") {
    o.characters = n.characters;
    o.textAutoResize = n.textAutoResize;
    const fn = num(n.fontName), fs = num(n.fontSize), ls = num(n.letterSpacing), lh = num(n.lineHeight), td = num(n.textDecoration);
    const style = { fontFamily: fn && fn.family, fontWeight: num(n.fontWeight), fontSize: fs, italic: !!(fn && /italic/i.test(fn.style)),
      textAlignHorizontal: n.textAlignHorizontal, textAlignVertical: n.textAlignVertical, textCase: num(n.textCase), textDecoration: td };
    if (ls && fs) style.letterSpacing = ls.unit === "PERCENT" ? (ls.value / 100) * fs : ls.value;
    if (lh && fs) {
      if (lh.unit === "AUTO") style.lineHeightUnit = "INTRINSIC_%";
      else { style.lineHeightUnit = "PIXELS"; style.lineHeightPx = lh.unit === "PERCENT" ? (lh.value / 100) * fs : lh.value; }
    }
    o.style = style;
    if ([n.fontName, n.fontSize, n.fills, n.fontWeight].some(v => v === M)) o.characterStyleOverrides = [1];
  }
  if (n.type === "INSTANCE") {
    const main = await n.getMainComponentAsync();
    if (main) {
      o.componentId = main.id;
      if (!main.remote && !componentsSeen.has(main.id)) componentsSeen.set(main.id, main);
    }
  }
  if ("children" in n) o.children = await Promise.all(n.children.map(ser));
  return o;
}

async function collectVariables() {
  const cols = await figma.variables.getLocalVariableCollectionsAsync();
  const vars = await figma.variables.getLocalVariablesAsync();
  const variableCollections = {}, variables = {};
  for (const c of cols) variableCollections[c.id] = { id: c.id, name: c.name, defaultModeId: c.defaultModeId, modes: c.modes };
  for (const v of vars) variables[v.id] = { id: v.id, name: v.name, resolvedType: v.resolvedType, variableCollectionId: v.variableCollectionId, valuesByMode: v.valuesByMode };
  return { meta: { variableCollections, variables } };
}

function contains(list, id) {
  for (const n of list) { if (n.id === id) return true; if (n.children && contains(n.children, id)) return true; }
  return false;
}

async function run() {
  const sel = figma.currentPage.selection;
  if (!sel.length) { figma.ui.postMessage({ type: "error", text: "Select one or more frames, then run the export again." }); return; }
  const selected = await Promise.all(sel.map(ser));
  // Pull in local main components used by instances so they convert as reusable components
  const extra = [];
  for (let i = 0; i < 20; i++) {
    const todo = [...componentsSeen.values()].filter(c => !contains(selected, c.id) && !contains(extra, c.id));
    if (!todo.length) break;
    for (const c of todo) extra.push(await ser(c.parent && c.parent.type === "COMPONENT_SET" ? c.parent : c));
  }
  const pages = [{ id: figma.currentPage.id, type: "CANVAS", name: figma.currentPage.name, children: selected }];
  if (extra.length) pages.push({ id: "components", type: "CANVAS", name: "Components (used by selection)", children: extra });
  const out = { figma2pen: 1, name: figma.root.name, document: { id: "0:0", type: "DOCUMENT", children: pages }, components: {}, variables: await collectVariables() };
  figma.ui.postMessage({ type: "result", text: JSON.stringify(out), count: selected.length, extra: extra.length });
}

figma.ui.onmessage = m => { if (m.type === "export") run().catch(e => figma.ui.postMessage({ type: "error", text: String(e && e.message || e) })); if (m.type === "close") figma.closePlugin(); };
run().catch(e => figma.ui.postMessage({ type: "error", text: String(e && e.message || e) }));
